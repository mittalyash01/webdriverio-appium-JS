
# Mobile Hackathon: Introduction


## Getting Started

Clone the repository and npm install.....

## Installation and Local setup
- **Install packages**: `npm install`

## Integrations
......

### Sauce labs
......

#### Shortcoming

#### Positive outlook
................

### BrowserStack
...........

#### Shortcoming

#### Positive outlook

### Perfecto
----------

#### Shortcoming

#### Positive outlook

### AWS Device Farm
-------------

#### Shortcoming

#### Positive outlook



## Running tests locally

`npx wdio {config} --spec {filename}`

## Overall Summary